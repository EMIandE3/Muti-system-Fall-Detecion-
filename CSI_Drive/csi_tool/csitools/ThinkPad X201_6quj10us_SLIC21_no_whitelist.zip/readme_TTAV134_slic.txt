-Manufacturer: Lenovo
-Model: ThinkPad X201, X201i, X201s, X201si and X201 Tablet 
-Bios Revision: 1.32
-Bios Release: 13 Jan 2011
-Bios link: http://download.lenovo.com/ibmdl/pub/pc/pccbbs/mobiles/6quj10us.exe
-Bios place: http://www-307.ibm.com/pc/support/site.wss/document.do?lndocid=MIGR-70656
-Bios Type: Phoenix BIOS
-SLIC: Lenovo[LENOVO-TP-6Q-LTP]2.1.BIN
-Tools: Phoenix Mod Tool v1.70 + PhnxPatch 0.1
-Modifier: TTAV134


WLAN/WWAN whitelists check "removed" + SLIC21

ThinkPad X201_6quj10us_SLIC21_no_whitelist.zip


Upon opening the WinPhlash 32 or 64 bit, click "Advanced Settings" then check and uncheck the boxes so it looks like this:

("Flags" Tab):
[ ] Verify BIOS part number
[ ] Flash only if BIOS version is different
[ ] Flash only if BIOS version is newer
[ ] Verify BIOS image size
[ ] Verify BIOS checksum
[ ] Zero block before erasing
[x] Verify block after programming
[x] Disable Axx swaping automatic detection (if present)
[ ] Clear CMOS Checksum

("DMI" tab)
